package com.promottv.app

import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.media3.common.MediaItem
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONArray
import org.json.JSONObject
import java.net.URLEncoder

private val Bg = Color(0xFF080808)
private val Panel = Color(0xFF171717)
private val Accent = Color(0xFFE50914)
private val Muted = Color(0xFFAAAAAA)

data class StreamItem(
    val id: String,
    val name: String,
    val categoryId: String = "",
    val streamType: String = "live",
    val extension: String = "ts",
    val icon: String? = null
)

data class XtreamAccount(val server: String, val username: String, val password: String) {
    fun apiUrl(action: String? = null): String {
        val base = server.trim().trimEnd('/')
        val query = "username=${enc(username)}&password=${enc(password)}" +
            (action?.let { "&action=${enc(it)}" } ?: "")
        return "$base/player_api.php?$query"
    }
    fun streamUrl(item: StreamItem): String {
        val base = server.trim().trimEnd('/')
        val ext = item.extension.ifBlank { if (item.streamType == "live") "ts" else "mp4" }
        val path = when (item.streamType) {
            "live" -> "live"
            "movie" -> "movie"
            else -> "series"
        }
        return "$base/$path/${enc(username)}/${enc(password)}/${item.id}.$ext"
    }
    private fun enc(value: String) = URLEncoder.encode(value, "UTF-8")
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = android.graphics.Color.rgb(8, 8, 8)
        window.navigationBarColor = android.graphics.Color.rgb(8, 8, 8)
        setContent { PromotApp() }
    }
}

@Composable
fun PromotApp() {
    var server by remember { mutableStateOf("") }
    var username by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    var account by remember { mutableStateOf<XtreamAccount?>(null) }
    var selectedTab by remember { mutableStateOf("Live TV") }
    var items by remember { mutableStateOf<List<StreamItem>>(emptyList()) }
    var selected by remember { mutableStateOf<StreamItem?>(null) }
    var loading by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf("") }
    val scope = rememberCoroutineScope()

    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = Accent, background = Bg, surface = Panel,
            onBackground = Color.White, onSurface = Color.White
        )
    ) {
        Surface(Modifier.fillMaxSize(), color = Bg) {
            if (selected != null && account != null) {
                PlayerScreen(
                    account = account!!,
                    item = selected!!,
                    onBack = { selected = null }
                )
            } else if (account == null) {
                LoginScreen(
                    server, { server = it }, username, { username = it },
                    password, { password = it }, loading, error
                ) {
                    val acc = XtreamAccount(server.trim(), username.trim(), password)
                    loading = true
                    error = ""
                    scope.launch {
                        val result = withContext(Dispatchers.IO) { validateAccount(acc) }
                        loading = false
                        if (result.first) {
                            account = acc
                            loadItems(acc, "live", { items = it }, { error = it }, { loading = it }, scope)
                        } else error = result.second
                    }
                }
            } else {
                HomeScreen(
                    tab = selectedTab,
                    onTab = { selectedTab = it },
                    items = items,
                    loading = loading,
                    error = error,
                    onSelect = { selected = it },
                    onRefresh = {
                        val type = when (selectedTab) {
                            "Movies" -> "movie"
                            "Series" -> "series"
                            else -> "live"
                        }
                        loadItems(account!!, type, { items = it }, { error = it }, { loading = it }, scope)
                    },
                    onLogout = { account = null; items = emptyList(); selected = null }
                )
                LaunchedEffect(selectedTab, account) {
                    val type = when (selectedTab) {
                        "Movies" -> "movie"
                        "Series" -> "series"
                        else -> "live"
                    }
                    loadItems(account!!, type, { items = it }, { error = it }, { loading = it }, scope)
                }
            }
        }
    }
}

@Composable
fun LoginScreen(
    server: String, onServer: (String) -> Unit,
    username: String, onUsername: (String) -> Unit,
    password: String, onPassword: (String) -> Unit,
    loading: Boolean, error: String, onLogin: () -> Unit
) {
    Column(
        Modifier.fillMaxSize().padding(horizontal = 26.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Text("PROMOT", color = Accent, fontSize = 38.sp, fontWeight = FontWeight.Black)
        Text("TV", color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(10.dp))
        Text("كل الترفيه في مكان واحد", color = Muted, fontSize = 14.sp)
        Spacer(Modifier.height(30.dp))
        OutlinedTextField(
            value = server, onValueChange = onServer, modifier = Modifier.fillMaxWidth(),
            label = { Text("Server URL") }, placeholder = { Text("http://example.com:8080") },
            singleLine = true, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Uri),
            colors = fieldColors()
        )
        Spacer(Modifier.height(12.dp))
        OutlinedTextField(
            value = username, onValueChange = onUsername, modifier = Modifier.fillMaxWidth(),
            label = { Text("Username") }, singleLine = true, colors = fieldColors()
        )
        Spacer(Modifier.height(12.dp))
        OutlinedTextField(
            value = password, onValueChange = onPassword, modifier = Modifier.fillMaxWidth(),
            label = { Text("Password") }, singleLine = true,
            visualTransformation = PasswordVisualTransformation(), colors = fieldColors()
        )
        if (error.isNotBlank()) {
            Spacer(Modifier.height(10.dp))
            Text(error, color = Color(0xFFFF7777), fontSize = 13.sp)
        }
        Spacer(Modifier.height(22.dp))
        Button(
            onClick = onLogin,
            enabled = !loading && server.isNotBlank() && username.isNotBlank() && password.isNotBlank(),
            modifier = Modifier.fillMaxWidth().height(52.dp),
            colors = ButtonDefaults.buttonColors(containerColor = Accent),
            shape = RoundedCornerShape(12.dp)
        ) {
            if (loading) CircularProgressIndicator(Modifier.size(20.dp), color = Color.White, strokeWidth = 2.dp)
            else Text("تسجيل الدخول", fontWeight = FontWeight.Bold)
        }
        Spacer(Modifier.height(18.dp))
        Text("يدعم حسابات Xtream Codes المتوافقة", color = Muted, fontSize = 11.sp)
    }
}

@Composable
fun fieldColors() = OutlinedTextFieldDefaults.colors(
    focusedBorderColor = Accent, unfocusedBorderColor = Color.DarkGray,
    focusedLabelColor = Accent, cursorColor = Accent
)

@Composable
fun HomeScreen(
    tab: String, onTab: (String) -> Unit, items: List<StreamItem>,
    loading: Boolean, error: String, onSelect: (StreamItem) -> Unit,
    onRefresh: () -> Unit, onLogout: () -> Unit
) {
    Column(Modifier.fillMaxSize()) {
        Row(
            Modifier.fillMaxWidth().padding(horizontal = 18.dp, vertical = 16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text("PROMOT", color = Accent, fontSize = 25.sp, fontWeight = FontWeight.Black)
            Text(" TV", color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.Bold)
            Spacer(Modifier.weight(1f))
            Text("خروج", color = Muted, modifier = Modifier.clickable { onLogout() })
        }
        Row(Modifier.fillMaxWidth().padding(horizontal = 12.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            listOf("Live TV", "Movies", "Series").forEach { name ->
                FilterChip(
                    selected = tab == name, onClick = { onTab(name) }, label = { Text(name) },
                    colors = FilterChipDefaults.filterChipColors(
                        selectedContainerColor = Accent, selectedLabelColor = Color.White
                    )
                )
            }
            Spacer(Modifier.weight(1f))
            Text("↻", color = Color.White, fontSize = 24.sp,
                modifier = Modifier.clickable { onRefresh() }.padding(horizontal = 8.dp))
        }
        Text(
            when (tab) { "Movies" -> "الأفلام"; "Series" -> "المسلسلات"; else -> "القنوات المباشرة" },
            color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.Bold,
            modifier = Modifier.padding(start = 18.dp, top = 22.dp, bottom = 12.dp)
        )
        when {
            loading -> Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                CircularProgressIndicator(color = Accent)
            }
            error.isNotBlank() -> Box(Modifier.fillMaxSize().padding(24.dp), contentAlignment = Alignment.Center) {
                Text(error, color = Color(0xFFFF7777))
            }
            items.isEmpty() -> Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                Text("لا توجد عناصر لعرضها", color = Muted)
            }
            else -> LazyColumn(contentPadding = PaddingValues(horizontal = 14.dp, vertical = 4.dp)) {
                items(items) { item ->
                    Row(
                        Modifier.fillMaxWidth().padding(vertical = 5.dp)
                            .background(Panel, RoundedCornerShape(10.dp))
                            .clickable { onSelect(item) }.padding(14.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(
                            Modifier.size(42.dp).background(Color(0xFF292929), RoundedCornerShape(8.dp)),
                            contentAlignment = Alignment.Center
                        ) { Icon(Icons.Default.PlayArrow, contentDescription = null, tint = Accent) }
                        Spacer(Modifier.width(12.dp))
                        Text(item.name, color = Color.White, modifier = Modifier.weight(1f), maxLines = 2)
                        Text("▶", color = Accent)
                    }
                }
            }
        }
    }
}

@Composable
fun PlayerScreen(account: XtreamAccount, item: StreamItem, onBack: () -> Unit) {
    val context = androidx.compose.ui.platform.LocalContext.current
    val player = remember(item) {
        ExoPlayer.Builder(context).build().apply {
            setMediaItem(MediaItem.fromUri(Uri.parse(account.streamUrl(item))))
            prepare()
            playWhenReady = true
        }
    }
    DisposableEffect(player) { onDispose { player.release() } }
    Column(Modifier.fillMaxSize().background(Color.Black)) {
        Row(Modifier.fillMaxWidth().padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onBack) { Icon(Icons.Default.ArrowBack, null, tint = Color.White) }
            Text(item.name, color = Color.White, fontWeight = FontWeight.Bold, maxLines = 1)
        }
        AndroidView(
            factory = { ctx -> PlayerView(ctx).apply { this.player = player; useController = true } },
            modifier = Modifier.fillMaxWidth().weight(1f)
        )
    }
}

private suspend fun validateAccount(account: XtreamAccount): Pair<Boolean, String> {
    return try {
        val json = fetchJson(account.apiUrl())
        val userInfo = json.optJSONObject("user_info")
        val auth = userInfo?.optInt("auth", 0) ?: 0
        if (auth == 1) true to "" else false to "بيانات الدخول غير صحيحة أو الحساب غير مفعل."
    } catch (e: Exception) {
        false to "تعذر الاتصال بالخادم. تحقق من الرابط والإنترنت."
    }
}

private fun loadItems(
    account: XtreamAccount, type: String,
    onItems: (List<StreamItem>) -> Unit, onError: (String) -> Unit,
    onLoading: (Boolean) -> Unit, scope: kotlinx.coroutines.CoroutineScope
) {
    scope.launch {
        onLoading(true)
        onError("")
        try {
            val action = when (type) {
                "movie" -> "get_vod_streams"
                "series" -> "get_series"
                else -> "get_live_streams"
            }
            // Xtream returns a top-level JSON array for stream actions.
            val raw = withContext(Dispatchers.IO) { fetchArray(account.apiUrl(action)) }
            val result = mutableListOf<StreamItem>()
            for (i in 0 until raw.length()) {
                val obj = raw.optJSONObject(i) ?: continue
                val id = obj.optString(if (type == "series") "series_id" else "stream_id")
                val name = obj.optString("name", "بدون اسم")
                if (id.isNotBlank() && id != "null") {
                    val ext = obj.optString("container_extension", if (type == "live") "ts" else "mp4")
                    result.add(StreamItem(id, name, obj.optString("category_id"), type, ext, obj.optString("stream_icon")))
                }
            }
            onItems(result)
        } catch (e: Exception) {
            onError("لم نتمكن من تحميل المحتوى. تحقق من اتصال Xtream Codes.")
        } finally { onLoading(false) }
    }
}

private val http = OkHttpClient.Builder().build()

private fun fetchJson(url: String): JSONObject {
    val request = Request.Builder().url(url).get().build()
    http.newCall(request).execute().use { response ->
        if (!response.isSuccessful) error("HTTP ${response.code}")
        return JSONObject(response.body?.string() ?: "{}")
    }
}

private fun fetchArray(url: String): JSONArray {
    val request = Request.Builder().url(url).get().build()
    http.newCall(request).execute().use { response ->
        if (!response.isSuccessful) error("HTTP ${response.code}")
        return JSONArray(response.body?.string() ?: "[]")
    }
}
